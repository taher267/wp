<?php 
//including stylesheet.css
function calling_style_resources() {
	wp_enqueue_style( 'styleSheet', get_stylesheet_uri();,'','1.0.0';
	wp_enqueue_style( 'otherStyle', get_template_directory_uri().'/assets/css/responsive.css','','1.0.0';
}
add_action( 'wp_enqueue_scripts', 'calling_style_resources' );


//including js file
function calling_scripts_resources() {
	wp_enqueue_script( 'mainJs', get_template_directory_uri(),'','1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'calling_scripts_resources' );

//register Nav Menu
function our_theme_setup(){
	register_nav_menus(array(
		'mainmenu'=>__('Primary Menu'),
	));

	//active thumbnail
	add_theme_support('post_thumbnails');

	//custom slider---------------------------------------------------------	
		$labels = array(
			'name'               => __( 'Plural Name', 'text-domain' ),
			'singular_name'      => __( 'Singular Name', 'text-domain' ),
			'add_new'            => _x( 'Add New Singular Name', 'text-domain', 'text-domain' ),
			'add_new_item'       => __( 'Add New Singular Name', 'text-domain' ),
			'edit_item'          => __( 'Edit Singular Name', 'text-domain' ),
			'new_item'           => __( 'New Singular Name', 'text-domain' ),
			'view_item'          => __( 'View Singular Name', 'text-domain' ),
			'search_items'       => __( 'Search Plural Name', 'text-domain' ),
			'not_found'          => __( 'No Plural Name found', 'text-domain' ),
			'not_found_in_trash' => __( 'No Plural Name found in Trash', 'text-domain' ),
			'parent_item_colon'  => __( 'Parent Singular Name:', 'text-domain' ),
			'menu_name'          => __( 'Plural Name', 'text-domain' ),
		);
	
		$slide_args =array(
			'labels' =>array(
				'name' => 'mySlider',
				'add_new_item'='Add New Slider',
			) ,
			'public' =>true,
			'supports' =>array(
				'title',
				'thumbnail',

			),
		);
		register_post_type( 'slug', $slide_args );
	
	
	




	//-------------------------------------------------------

}
add_action('after_theme_setup', 'our_theme_setup');

//excerpt Function
function excerpt($num){
	$limit= $num+1;
	$excerpt = explode('',get_the_excerpt( ), $limit);
	array_pop($excerpt);
	$excerpt = implode(" ",$excerpt)."<a href='".get_permalink( $post->ID)."'class='".readmore."'>[.....]</a>";
	echo $excerpt;
}

// Custom Pagination start
function pagination($pages = '', $range = 4){ 
    $showitems = ($range * 2)+1;        
	global $paged;     
	if(empty($paged)) $paged = 1;      
	if($pages == ''){         
		global $wp_query;         
		$pages = $wp_query->max_num_pages;         
		if(!$pages){$pages = 1;}
	}
	if(1 != $pages){
		echo "<div class=\"pagination\"><span>Page No- ".$paged." of ".$pages."</span>";
		
		if($paged > 2 && $paged > $range+1 && $showitems < $pages) 
			echo "<a href='".get_pagenum_link(1)."'>&laquo; First</a>";
		
		if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo; Previous</a>";
		
		for ($i=1; $i <= $pages; $i++){
			if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )){
				echo ($paged == $i)? "<span class=\"current\">".$i."</span>":"<a href='".get_pagenum_link($i)."' class=\"inactive\">".$i."</a>";             
				}
		} 
		if ($paged < $pages && $showitems < $pages) 
			echo "<a href=\"".get_pagenum_link($paged + 1)."\">Next Page &rsaquo;</a>";           if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>Last Page &raquo;</a>";
		echo "</div>\n";
	}}

//Custom Pagination End



//SideBar Regisrtation
function sideWidgetInit(){
	$args = array(
	'name'          => __( 'Right Sidebar'), //or 'Right sidebar',
	'id'            => 'mainSideBar',
	//'class'         => 'mainSideBar', extra from Itbari
	'before_widget' => '<aside class="main_Side_Bar">',
	'after_widget'  => '</aside>',
	'before_title'  => '<h3>',
	'after_title'   => '</h3>',
	);

	register_sidebar( $args );
}
add_action('widgets_init','sideWidgetInit');





