<!-- have to include 
<?php //get_template_part('menu'); ?> -->
<div class="mainMenu">
	<nav> <!-- <ul><li><a href="#">HOME</a></li></ul> instead of this-->
		<div id="nav">
			<?php // for active menu, have to registeration on function.php
				$args = array(
					'theme_location' =>'mainmenu'
				);
				wp_nav_menu( $args );


			 ?>
		</div>
	</nav>		
</div>


<?php 
// for fucntions.php
// function our_theme_setup(){
// 	register_nav_menus(array(
// 		'mainmenu'=>__('Primary Menu'),
// 	));
// }
// add_action('after_theme_setup', 'our_theme_setup');

 ?>