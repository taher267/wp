<?php get_header()); ?>

	<h2><?php bloginfo('name') ?> </h2>
	<p><?php bloginfo('description' ); ?> </p>
	<!-- for Menu -->
	<?php get_template_part('menu'); ?>
	<!-- The file doesn't any slider content -->

<section>
	<div class="container">
		<div class="row">
			<div class="col-md-10">
			Lorem ipsum dolor, sit amet consectetur, adipisicing elit. Reprehenderit possimus saepe vel omnis est harum nesciunt cum, quisquam officia sunt blanditiis officiis soluta accusantium dolore animi laboriosam quidem sit natus.
			</div>
			<div class="col-md-2">
				<?php get_template_part( 'sidebar'); ?>
			</div>
		</div>
	</div>
</section>
<section>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<?php if (have_posts()):
				while(have_posts()): the_post(); ?>
					<article>
						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> </h2>
						<div class="articaleContant">
							<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail();?></a>
							
						<p><?php echo the_content(); ?></p> <!-- number of word(20) fm for client for excerpt and have to register on functions.php-->
						</div>
					</article>
				<?php endwhile;	endif; ?>



					<!-- <article>
						<h2><a href="#">This is heading</a> </h2>
						<div class="articaleContant">
							<a href="#"><img src="images/images" alt=""></a>
							<p>Lorem ipsum dolor, sit amet, consectetur adipisicing elit. Quae corrupti provident ratione praesentium aliquam iste qui reprehenderit facilis, sint fugiat voluptas, dicta rem commodi eligendi, nostrum molestiae atque deleniti quo.</p>
						</div>
					</article> -->

					<!-- Pagination -->
					<?php 
						if(function_exists("pagination")){
							pagination(	$additional_loop->max_num_pages);
						}?>

			</div>
		</div>
	</div>
</section>



	<img src="<?php get_template_directory_uri();?>/images/somethhin.jpg" alt="">










<?php get_footer(); ?>