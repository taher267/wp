<!-- have to include 
<?php //get_template_part('menu'); ?> -->
<!-- <div class="mainMenu">
	<ul>
		<li><a href="#">HOME</a></li>
		<li><a href="#">HOME</a></li>
		<li><a href="#">HOME</a></li>
		<li><a href="#">HOME</a></li>
		<li><a href="#">HOME</a></li>
	</ul>
</div> -->

<section class="jaza_slider">
	<div class="owlcarousel owl-theme">
		<?php 
			$custSlide=new WP_Query(
				array(
					'post_type' => '', //register_post_type's id which is registered in function.php
				)
			);

		if ($custSlide->the_posts()):
			while ($custSlide->the_posts()):$custSlide->the_post();?>
			<?php the_post_thumbnail( ); ?>
		<?php endwhile; endif ?>
		
	</div>
</section>