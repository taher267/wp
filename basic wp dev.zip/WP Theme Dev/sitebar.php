<!-- have to include  -->
<!-- <?php //get_template_part('sitebar'); ?> -->
<div class="sidebar">
	<aside>
<?php 
		dynamic_sidebar('mainSideBar'); // and have to wp dashboard> widget> mainSideBar's Name

 ?>
	<!-- <h2>sidebar 01</h2>
	<ul>
		<li><a href="#">HOME</a></li>
		<li><a href="#">HOME</a></li>
		<li><a href="#">HOME</a></li>
		<li><a href="#">HOME</a></li>
		<li><a href="#">HOME</a></li>
	</ul> -->
	</aside>
</div>