<<!DOCTYPE html>
<html lang="<?php language_atrributes();?> ">
<head>
	<meta charset="<?php bloginfo('charset');?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php bloginfo('name') ?> </title>
	<?php wp_head(); ?>
</head>
<body <?php body_class() ); ?> >	
	<h2><a href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a> </h2>